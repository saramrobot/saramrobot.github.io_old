package com.saramrobot.pandora;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/search")
public class search extends HttpServlet {
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		resp.setCharacterEncoding("UTF-8");
		resp.setContentType("text/html; charset=UTF-8");
		
		PrintWriter out = resp.getWriter();
		
		String category_str = req.getParameter("category");
		
		
		int category = 0;
		
		if( category_str != null ) category = Integer.parseInt(category_str);

		Connection conn = null; // DB ������ ��ü ����
		String query = "SELECT * FROM cosmetics WHERE c_category=?";
		PreparedStatement pstmt = null;
		
		try { // jdbc connect j ���̺귯�� �ε� ���� ó��
			Class.forName("org.mariadb.jdbc.Driver"); // �ش� Ŭ������ �޸𸮿� �ε� �� ����
		} catch (ClassNotFoundException e) {
			System.out.println("ClassNotFoundException: " + e.getMessage());
		} 

		try { // drive Ŭ������ �̿��� Ŀ�ؼ� ��ü�� localhost:3306/DB �� ���� �� ����ó��
			String url = "jdbc:mysql://18.116.15.236:3306/beauty";
			
			conn = DriverManager.getConnection(url, "root", "wjdqhqhdks"); // DB �α��� ������ ����
			
		} catch (SQLException e) {
			System.out.println("SQLException: " + e.getMessage());
			System.out.println("SQLState: " + e.getSQLState());
			System.out.println("VendorError: " + e.getErrorCode());
		} finally {
			try {
		        pstmt = conn.prepareStatement(query);		        
		        pstmt.setInt(1, category);
		        ResultSet rs = pstmt.executeQuery();
		        
		        resp.getWriter().println("UID\tName\tCategory<br>");
		        while(rs.next()){     
                   String uid_ = rs.getString("c_uid");
                   String name_ = rs.getString("c_name");
                   String category_ = rs.getString("c_category");
                   
                   resp.getWriter().println(uid_ + "\t" + name_ +  "\t" + category_ + "<br>");
                }

				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

}
